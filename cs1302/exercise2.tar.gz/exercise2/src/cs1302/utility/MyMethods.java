package cs1302.utility;
public class MyMethods {
    public static int max(int m, int n) {
	if (m >= n){
	    return m;
	}
	else {
	    return n;
	}
    }
}
